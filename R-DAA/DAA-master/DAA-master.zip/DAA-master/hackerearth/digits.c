#include<stdio.h>
char str1[],str2[],t[];
int main()
{
	scanf("%s %s %s",str1,t,str2);
	printf("%s\n",str2);
}
